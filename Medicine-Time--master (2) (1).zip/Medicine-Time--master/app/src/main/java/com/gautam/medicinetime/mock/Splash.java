package com.gautam.medicinetime.mock;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.gautam.medicinetime.R;
import com.gautam.medicinetime.medicine.MedicineActivity;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent int1=new Intent(getApplicationContext(), MedicineActivity.class);
                    startActivity(int1);
                    finish();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        },3000);
    }
}
